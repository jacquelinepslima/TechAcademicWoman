import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adicionar',
  templateUrl: './adicionar.component.html'
})
export class AdicionarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
